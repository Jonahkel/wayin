(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_venue-map_tsx_81bc2df6._.js",
  "static/chunks/node_modules_c02f529e._.js",
  "static/chunks/_69a81120._.js"
],
    source: "dynamic"
});
