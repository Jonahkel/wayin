(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/venue-map.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VenueMap",
    ()=>VenueMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const DEFAULT_CENTER = [
    42.2808,
    -83.743
];
const DEFAULT_ZOOM = 15;
function createMarkerIcon(isSelected) {
    const bg = isSelected ? "#2d3a4a" : "#c0392b";
    const size = isSelected ? 36 : 28;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].divIcon({
        className: "custom-marker",
        html: `<div style="
      width: ${size}px;
      height: ${size}px;
      background: ${bg};
      border: 3px solid #fff;
      border-radius: 50% 50% 50% 0;
      transform: rotate(-45deg);
      box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    "></div>`,
        iconSize: [
            size,
            size
        ],
        iconAnchor: [
            size / 2,
            size
        ],
        popupAnchor: [
            0,
            -size
        ]
    });
}
function VenueMap({ venues, selectedVenue, onSelectVenue }) {
    _s();
    const mapContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const mapRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const markersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const onSelectVenueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(onSelectVenue);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VenueMap.useEffect": ()=>{
            onSelectVenueRef.current = onSelectVenue;
        }
    }["VenueMap.useEffect"], [
        onSelectVenue
    ]);
    // Initialize map
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VenueMap.useEffect": ()=>{
            if (!mapContainerRef.current || mapRef.current) return;
            const map = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].map(mapContainerRef.current, {
                center: DEFAULT_CENTER,
                zoom: DEFAULT_ZOOM,
                zoomControl: true,
                attributionControl: true,
                keyboard: true,
                scrollWheelZoom: true
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 19
            }).addTo(map);
            mapRef.current = map;
            return ({
                "VenueMap.useEffect": ()=>{
                    map.remove();
                    mapRef.current = null;
                }
            })["VenueMap.useEffect"];
        }
    }["VenueMap.useEffect"], []);
    // Update markers when venues change
    const updateMarkers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "VenueMap.useCallback[updateMarkers]": ()=>{
            const map = mapRef.current;
            if (!map) return;
            // Remove old markers
            markersRef.current.forEach({
                "VenueMap.useCallback[updateMarkers]": (marker)=>marker.remove()
            }["VenueMap.useCallback[updateMarkers]"]);
            markersRef.current.clear();
            venues.forEach({
                "VenueMap.useCallback[updateMarkers]": (venue)=>{
                    const isSelected = selectedVenue?.id === venue.id;
                    const marker = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].marker([
                        venue.lat,
                        venue.lng
                    ], {
                        icon: createMarkerIcon(isSelected),
                        title: venue.name,
                        alt: `${venue.name} location marker`
                    });
                    marker.bindPopup(`<div style="min-width: 140px; font-family: system-ui, sans-serif;">
          <strong style="font-size: 14px;">${venue.name}</strong>
          <p style="font-size: 12px; margin: 4px 0 0; color: #555;">${venue.description || venue.address}</p>
        </div>`, {
                        closeButton: true
                    });
                    marker.on("click", {
                        "VenueMap.useCallback[updateMarkers]": ()=>{
                            onSelectVenueRef.current(venue);
                        }
                    }["VenueMap.useCallback[updateMarkers]"]);
                    marker.addTo(map);
                    markersRef.current.set(venue.id, marker);
                }
            }["VenueMap.useCallback[updateMarkers]"]);
        }
    }["VenueMap.useCallback[updateMarkers]"], [
        venues,
        selectedVenue
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VenueMap.useEffect": ()=>{
            updateMarkers();
        }
    }["VenueMap.useEffect"], [
        updateMarkers
    ]);
    // Pan to selected venue
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VenueMap.useEffect": ()=>{
            if (!selectedVenue || !mapRef.current) return;
            const marker = markersRef.current.get(selectedVenue.id);
            if (marker) {
                mapRef.current.panTo([
                    selectedVenue.lat,
                    selectedVenue.lng
                ], {
                    animate: true,
                    duration: 0.5
                });
                marker.openPopup();
            }
        }
    }["VenueMap.useEffect"], [
        selectedVenue
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: mapContainerRef,
        role: "application",
        "aria-label": "Interactive map showing venue locations in Ann Arbor",
        "aria-roledescription": "map",
        className: "size-full",
        style: {
            minHeight: "300px"
        }
    }, void 0, false, {
        fileName: "[project]/components/venue-map.tsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
_s(VenueMap, "KwypSq1R4l1n+8MAZAegtrQpc7s=");
_c = VenueMap;
var _c;
__turbopack_context__.k.register(_c, "VenueMap");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/venue-map.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/components/venue-map.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=components_venue-map_tsx_e7c54902._.js.map